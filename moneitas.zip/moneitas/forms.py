from django import forms
from .models import RegistroFinanciero, Etiqueta
from datetime import date

class RegistroFinancieroForm(forms.ModelForm):
    etiqueta_existente = forms.ModelChoiceField(
        queryset=Etiqueta.objects.all(),
        required=False,
        empty_label="Elige una etiqueta existente (opcional)"
    )
    etiqueta_personalizada = forms.CharField(
        max_length=255,
        required=False,
        label="O crea una nueva etiqueta (opcional)"
    )

    fecha = forms.DateField(initial=date.today())

    class Meta:
        model = RegistroFinanciero
        fields = ['tipo', 'monto', 'fecha', 'etiqueta_existente', 'etiqueta_personalizada', 'nota']
