from django.db import models

class Etiqueta(models.Model):
    nombre = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return self.nombre

class RegistroFinanciero(models.Model):
    TIPO_CHOICES = (
        ('ingreso', 'Ingreso'),
        ('gasto', 'Gasto'),
    )

    tipo = models.CharField(max_length=7, choices=TIPO_CHOICES)
    monto = models.DecimalField(max_digits=10, decimal_places=2)
    fecha = models.DateField()
    etiqueta = models.ForeignKey(Etiqueta, on_delete=models.CASCADE, blank=True, null=True)
    nota = models.TextField(blank=True, null=True)
    eliminar = models.BooleanField(default=False)  # Campo para identificar registros a eliminar


    def __str__(self):
        return f"{self.get_tipo_display()}: {self.monto} - {self.fecha}"

