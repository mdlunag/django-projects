from django.shortcuts import render, redirect
from .models import RegistroFinanciero
from .forms import RegistroFinancieroForm
from .models import Etiqueta
from datetime import date,timedelta,datetime


from django.shortcuts import render
from django.db.models import Sum
from calendar import month_name

def crear_registro_financiero(request):
    if request.method == 'POST':
        form = RegistroFinancieroForm(request.POST)
        if form.is_valid():
            etiqueta_existente = form.cleaned_data['etiqueta_existente']
            etiqueta_personalizada = form.cleaned_data['etiqueta_personalizada']

            # Verifica si se seleccionó una etiqueta existente o se proporcionó una etiqueta personalizada.
            if etiqueta_existente:
                etiqueta = etiqueta_existente
            elif etiqueta_personalizada:
                # Crea una nueva etiqueta personalizada.
                etiqueta = Etiqueta.objects.create(nombre=etiqueta_personalizada)
            else:
                # Maneja el caso en el que no se proporciona ninguna etiqueta.
                etiqueta = None

            # Crea el registro financiero con la etiqueta asociada.
            nuevo_registro = form.save(commit=False)
            nuevo_registro.etiqueta = etiqueta  # Asocia la etiqueta con el registro financiero
            nuevo_registro.save()

            return redirect('overview_dashboard')  # Puedes redirigir a una página de éxito o a donde necesites
    else:
        form = RegistroFinancieroForm(initial={'fecha': date.today()})  # Prellenar la fecha con la fecha actual

    return render(request, 'moneitas/tu_template.html', {'form': form})


def overview_dashboard(request):
    # Obtener la fecha actual
    current_date = date.today()

    # Obtener el mes seleccionado del parámetro GET, si está presente
    selected_month = request.GET.get('month', current_date.month)

    # Calcular el primer día del mes actual
    first_day_of_month = current_date.replace(day=1)

    # Calcular el último día del mes actual
    last_day_of_month = (
        first_day_of_month.replace(
            month=first_day_of_month.month % 12 + 1,
            year=first_day_of_month.year + first_day_of_month.month // 12,
            day=1
        ) - timedelta(days=1)
    )

    # Filtrar ingresos y gastos por el mes seleccionado
    incomes = RegistroFinanciero.objects.filter(
        tipo='ingreso',
        fecha__range=[first_day_of_month, last_day_of_month]
    ).aggregate(Sum('monto'))['monto__sum'] or 0

    expenses = RegistroFinanciero.objects.filter(
        tipo='gasto',
        fecha__range=[first_day_of_month, last_day_of_month]
    ).aggregate(Sum('monto'))['monto__sum'] or 0

    # Calcular el saldo total
    balance = incomes - expenses

    # Obtener una lista de meses con datos
    months_with_data = RegistroFinanciero.objects.filter(
        fecha__year=current_date.year
    ).dates('fecha', 'month')

    # Convertir los objetos de fecha a nombres de mes legibles
    month_choices = [(month.month, month_name[month.month]) for month in months_with_data]

    # Obtener la fecha actual
    current_date = date.today()

    # Obtener el mes seleccionado del parámetro GET, si está presente
    selected_month = request.GET.get('month', current_date.month)

    # Obtener el primer y último día del mes seleccionado
    selected_month_start = current_date.replace(month=int(selected_month), day=1)
    selected_month_end = selected_month_start.replace(
        month=selected_month_start.month % 12 + 1,
        year=selected_month_start.year + selected_month_start.month // 12,
        day=1
    ) - timedelta(days=1)

    # Filtrar los registros financieros por el mes seleccionado
    registros_financieros = RegistroFinanciero.objects.filter(
        fecha__range=[selected_month_start, selected_month_end]
    )

    if request.method == 'POST':
        # Procesar el formulario de eliminación
        for registro in registros_financieros:
            if request.POST.get(f"eliminar_{registro.id}") == 'on':
                registro.delete()

    return render(request, 'moneitas/dashboard.html', {
        'current_date': current_date,
        'incomes': incomes,
        'expenses': expenses,
        'balance': balance,
        'selected_month': int(selected_month),
        'month_choices': month_choices,
        'registros_financieros': registros_financieros,

    })
